#!/bin/sh

exec 2>/dev/null
touch /tmp/meow
timeout 60 /home/chal/chal